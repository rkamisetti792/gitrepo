Great! Your learner now has information about what they're expected to do in this step of the course.

Let's now find the `event` that will trigger the step. Because we want the learner to open a new Pull Request, the event we're looking for is `pull_request.opened`.