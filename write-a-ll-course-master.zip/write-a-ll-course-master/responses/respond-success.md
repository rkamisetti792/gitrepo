When your learner is successful, gates let the actions that follow execute.

Let's respond to the learner letting them know they've completed our course upon successfully open the PR with a proper title. 

Activity: 
1. In the same step, add a respond action.
1. Add a `with:` option for the response file.

We created the response file for you but feel free to change it. 

You can also accept the suggested changes below.