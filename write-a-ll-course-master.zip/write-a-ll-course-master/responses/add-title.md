Great! You opened the PR.

Now let's give your course a title. You can do so by editing `config.yml` directly and changing the title field, or accepting the suggestion below. 