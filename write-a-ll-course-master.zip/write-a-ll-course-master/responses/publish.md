Your course is now complete! Let's publish it. 

Merge this PR. Then go to sandbox/org/new and type in this repo's name. I'll respond when the course publishes. 

(Not really - we can't yet listen for a course published event)