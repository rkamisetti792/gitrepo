Great! The title will appear anywhere the course is referenced. We'll fill in some more of the course metadata later. Let's get into its nuts and bolts though. 

Most courses make use of a template repo. Template repos are cloned for the learner and can contain starter code or resources to help them find their way. 

Let's add our own template repo. To speed things up, we've created a template repo for you. We recommend going with this one.

You can edit the file directly or accept the suggested change below. 