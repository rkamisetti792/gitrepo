Great, we referenced a file title `welcome-text.md`, but it doesn't exist. Learning Lab automatically looks in the `responses/` directory for all content files. Let's add it.

Activity: add a response

1. In the `/responses/` folder, create a new file titled `welcome-text.md`
1. In that file, add some content that will appear to the learner in the welcome issue. 
1. Add an instruction for the learner to open a new PR titled "Add name to README" in which they add their name to the README file. 