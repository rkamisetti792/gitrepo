Remember your course's metadata, near the top of your config? We left the description and tagline but it's not time to fill it in.

Accept the suggested changes below or change the lines manually. 