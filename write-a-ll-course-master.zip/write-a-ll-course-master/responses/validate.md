Let's now validate the learner's PR. We asked them to title the PR "Add name to README" so that's what we need to validate against.

The action that will help us validate the learner's PR is a `gate`. Gates are conditionals, and they behave much like a conditional in Javascript. Let's add a `gate`, we'll specify its options in a later step.

Activity: add a gate

1. Add a gate or accept the suggested change below. 