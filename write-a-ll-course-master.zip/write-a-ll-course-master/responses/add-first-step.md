Great! The learner's repo will now be setup. Let's now dive into the `steps:`. This block is composed of steps that are triggered by `events` on GitHub, and in turn certain `actions` take place. 

Note: `actions` in this context is NOT the same as GitHub Actions.

Let's name our first step. 