Awesome! The learner's repo will now be cloned from `lab-starter-template`. We probably don't want that to be the learner's repo name though, so let's ensure that the learner-facing name is better. 

Change the field `name:` as part of the `template:` section to anything you like. You can also accept the suggestion below. 