Welcome. There's some boilerplate in your Code tab which contains most of what you need to get your Learning Lab course up and running.

However, we need to fill in some of the fields. I've started a branch with the first changes.

Activity: Open a PR for the title

1. [Open a pull request]({{ prUrl }}) against `add-metadata`.