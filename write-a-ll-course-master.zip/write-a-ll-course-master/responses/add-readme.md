The last thing that remains is a README. This file is show no the course's page, whenever the learner is thinking of registering. Typically this file should contain learning outcomes and some long form content. 

We added a README for you, but go ahead and put in your own content.