These deployment YAML files are adapted for use with Kong Enterprise Edition (EE) trials.

See more details at https://getkong.org/install/kubernetes/
