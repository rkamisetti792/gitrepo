#!/bin/bash
for ANIMAL in man bear pig dog cat sheep
do
  echo "$ANIMAL"
done
