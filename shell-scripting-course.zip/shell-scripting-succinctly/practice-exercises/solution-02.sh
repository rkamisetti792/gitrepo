#!/bin/bash
MESSAGE="Shell Scripting is Fun!"
echo "$MESSAGE"
