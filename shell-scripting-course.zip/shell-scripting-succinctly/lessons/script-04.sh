#!/bin/zsh
echo "This script uses zsh as the interpreter."
