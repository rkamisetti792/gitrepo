#!/bin/bash -v

TEST_VAR="test"
echo "$TEST_VAR"
