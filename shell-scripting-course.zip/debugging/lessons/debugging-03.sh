#!/bin/bash -e

FILE_NAME="/not/here"
ls $FILE_NAME
echo $FILE_NAME
