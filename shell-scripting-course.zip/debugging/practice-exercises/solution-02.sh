#!/bin/bash -x

ls /etc/passwd
ls /move/along/nothing/to/see/here
ls /etc/passwd
