#
# This is python code to run a Qualys scan and report on a dedicated HSM appliance.
#
# IMPORTANT:
# In order to run this code all the following information must be verified in advance
# for the existing Qualys account at https://www.qualys.com/
#
#   SCANNER_APPLIANCE - Qualys scanner appliance (at Scans/Appliances)
#   SCAN_OPTION_PROFILE - Payment Card Industry (PCI) Options (at Scans/Option Profiles)
#   TEMPLATE_ID - Scan Template ID for 'Automation Scan Template' (at Reports/Templates)
#   TARGET_IP - HSM appliance IP
#

import io
import itertools as IT

import requests
import xml.etree.ElementTree as ET
from xml.etree.ElementTree import ParseError
import time

from sys import argv

QUALYS_HTTPS = 'https://qualysapi.qg2.apps.qualys.com'

# Virtual scanner: QUALYS-SCANNER
SCANNER_APPLIANCE = 'QUALYS-SCANNER'
# Option profile: Payment Card Industry (PCI) Options
SCAN_OPTION_PROFILE = 'Payment Card Industry (PCI) Options'
# Scan Template ID: '1454834'. This is a customized scan template to cover in automation.
TEMPLATE_ID = '1454834'
# PDF is prefered report output format
OUTPUT_FORMAT = 'pdf'
# Appliance (target) ip: 10.164.74.27
TARGET_IP = '10.164.74.14'

verbose = True # verbose display

def login(s):
    #
    # ---Session Login---
    #
    # Logs into a Qualys session given a requests.Session object 's'.
    # A Session.post() always returns a response, here assigned 'r'.
    #

    payload = {
               'action':'login',
               'username':'safen2ks',
               'password':'Qualy5_5can'
               }
    print "Before post"
    r = s.post(QUALYS_HTTPS + '/api/2.0/fo/session/', data=payload)
    print "After post"
    
    # Verbose output
    if verbose == True:
        print r.text # prints the full xml response from Qualys
        # Parse the response.
        xmlreturn = ET.fromstring(r.text)
        for elem in xmlreturn.findall('.//TEXT'):
            print elem.text   # Prints the "Logged in" message
    return r.status_code


def logout(s):
    #
    # ---Logout---
    #
    # Logs out a Qualys session given a session object 's'.
    #

    payload = {
               'action':'logout'
               }

    r = s.post(QUALYS_HTTPS + '/api/2.0/fo/session/', data=payload)

    # Verbose output
    if verbose == True:
        print r.text # prints the full xml response from Qualys

        # Parse the response
        xmlreturn = ET.fromstring(r.text)
        for elem in xmlreturn.findall('.//TEXT'):
            print elem.text   # prints the "Logged out" message

    return r.status_code


def launchScan(s, targetIP, scanTitle):
    #
    #---Launch Scan---
    #
    # Launches a scan given a target IP and returns the reference string
    # to be used when checking the scan status and starting a report.
    #

    payload = {
               'action':'launch',
               'echo_request':1,
               'scan_title':scanTitle,
               'target_from':'assets',
               'ip':targetIP,
               'iscanner_name':SCANNER_APPLIANCE,
               'option_title':SCAN_OPTION_PROFILE
               }

    scanRef = None

    r = s.post(QUALYS_HTTPS + '/api/2.0/fo/scan/', data=payload)

    # Verbose output
    if verbose == True:
        print r.text # prints the full xml response from Qualys

    # Parse the response
    xmlreturn = ET.fromstring(r.text)
    for elem in xmlreturn.findall('.//ITEM'):
        if (elem[0].text == 'REFERENCE'):
            scanRef = elem[1].text

    return scanRef


def checkScan(s, scanRef):
    #
    #---Check Scans---
    #
    # Checks the status of our scan.
    #

    payload = {
               'action':'list',
               'scan_ref':scanRef,
               }

    r = s.post(QUALYS_HTTPS + '/api/2.0/fo/scan/', data=payload)

    # Verbose output
    if verbose == True:
        print r.text   # prints the full xml response from Qualys

    # Parse the response
    xmlreturn = ET.fromstring(r.text)
    for elem in xmlreturn.findall('.//STATUS'):
        status = elem[0].text
        if verbose == True:
            print elem[0].text   # prints the status message

    return status # Running. Paused, Canceled, Finished, Error, etc


def launchReport(s, scanRef, templateID, outputFormat, targetIP, reportTitle):
    #
    #---Launch Report---
    #
    # Launches a Scan Report given a scanRef, templateID, outputFormat,
    # targetIP and reportTitle. Returns the reference string to be used
    # when checking the status of the report and downloading it.
    # Note: obtain template_id from the web interface, reports > templates
    # and then select 'info' from the drop-down on the particular template
    # you want to use.
    #

    payload = {
               'action':'launch',
               'report_type':'Scan',
               'report_refs':scanRef,
               'template_id':templateID,
               'output_format':outputFormat,
               'report_title':reportTitle
               }

    reportID = None

    r = s.post(QUALYS_HTTPS + '/api/2.0/fo/report/', data=payload)

    # Verbose output
    if verbose == True:
        print r.text   # prints the full xml response from Qualys

    # Parse the response
    xmlreturn = ET.fromstring(r.text)
    for elem in xmlreturn.findall('.//ITEM'):
        if (elem[0].text == 'ID'):
            reportID = elem[1].text

    return reportID


def checkReport(s, reportID):
    #
    #---Check Reports---
    #
    # Checks the status of our Report.
    #

    payload = {
               'action':'list',
               'id':reportID,
               }

    r = s.post(QUALYS_HTTPS + '/api/2.0/fo/report/', data=payload)

    # Verbose output
    if verbose == True:
        print r.text   # prints the full xml response from Qualys

    # Parse the response
    xmlreturn = ET.fromstring(r.text)
    for elem in xmlreturn.findall('.//STATUS'):
        status = elem[0].text
        if verbose == True:
            print elem[0].text  # prints the status message

    return status


def downloadReport(s, reportID, fileName):
    #
    #---Download Report---
    #
    # Lets get the report.
    #

    payload = {
               'action':'fetch',
               'id':reportID,
               }

    r = s.post(QUALYS_HTTPS + '/api/2.0/fo/report/', data=payload)

    # Verbose output
    #if verbose == True:
    #    print r.text   # prints the full xml response from Qualys

    # Get that report.
    # No chunking needed due to small size of a single IP scan report.

    with open(fileName, "wb") as report:
        report.write(r.content)


def main():
    #
    #---main---
    #
    # Arguments:
    #   argv[1] - build version
    #   argv[2] - report type
    #
    # Example: python qualys_scan_n_report.py 2.2.0-1 Vulnerability IP
    #

    if len(argv) > 3:
        scanTitle = 'Automatic Vulnerability Scan Report for ' + argv[1]
        reportTitle = 'Automatic Vulnerability Scan Report for ' + argv[1]
        reportFname = argv[2] +'Qualys_Scan_Report_'  + argv[1] + '.pdf'
        TARGET_IP = argv[3]

    print "Request session:"
    print "scanTitle :",scanTitle
    print "reportFname :",reportFname
    print "TARGET_IP :",TARGET_IP

    s = requests.Session()

    s.headers.update({'X-Requested-With':'Facklers PyQual python primer'})
    print "Login to remote Qualys server:"

    retValue =  login(s)
    
    if ( retValue == 200 ):

        print "Starting Qualys scan for appliance:"
        print "  Title: ", scanTitle
        print "  Session: ", id(s)
        print "  HSM IP:", TARGET_IP

        scanRef = launchScan(s, TARGET_IP, scanTitle)
        if scanRef == None:
            print "Qualys scan failed !"
        else:
            # These API calls are valuable commodities, lets wait at least 10 minutes before we check.
            print "Waiting 600 seconds for scan to finish ..."
            time.sleep(600)

            # Lets check on the scan status.
            while checkScan(s, scanRef) != "Finished":
                print "Waiting 600 seconds for scan to finish ..."
                time.sleep(600)

        print "Launching Qualys report:"
        print "  Title:", reportTitle
        print "  Scan Reference:", scanRef
        print "  Output Format:", OUTPUT_FORMAT

        reportID = launchReport(s, scanRef, TEMPLATE_ID, OUTPUT_FORMAT, TARGET_IP, reportTitle)
        if reportID == None:
            print "Qualys report failed !"
        else:
            # Apparently asking about a report too soon after initiating it causes
            # bad responses which breaks checkReport()
            print "Waiting 150 seconds for report to finish ..."
            time.sleep(150)
            # OK, now lets check on the report, reports go faster so we can shorten the interval.
            while checkReport(s, reportID) != "Finished":
                print "Waiting 150 seconds for report to finish ..."
                time.sleep(150)

            print "Downloading report ..."
            downloadReport(s, reportID, reportFname)

        logout(s)
    else:
        print "Failed to login (error=", retValue, ")"

    s.close()

if __name__ == "__main__": main()


